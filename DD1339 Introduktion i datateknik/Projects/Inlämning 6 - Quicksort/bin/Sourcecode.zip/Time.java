/**
 * The Time class is the class that measures the time is take to sort a array
 * 
 * @author Felix De Silva
 * @date 28 feb 2014
 */
public class Time {
	/**
	 * the main method of the class
	 * 
	 * @param args
	 */
	public static void main(String[] args){
		measureQuickSortMiddle(1000);
		measureQuickSortInsertionMiddle(1000);
		measureQuickSortRandom(1000);
		measureQuickSortInsertionRandom(1000);
	}

	/**
	 * Measure the time for the QuickSort method that has the pivot point at the first element.
	 * 
	 * @param size - the size of the vector
	 */
	public static void measureQuickSortMiddle(int size){
		QuickSortMiddle sorter = new QuickSortMiddle();
		System.out.println("QuickSort + Middle pivot: " + size + " elements" );

		measureSorter(size, sorter);
	}

	/**
	 * Measure the time for the QuickSort method that has the pivot point at random elements.
	 * 
	 * @param size - the size of the vector
	 */
	public static void measureQuickSortRandom(int size){
		QuickSortRandom sorter = new QuickSortRandom();
		System.out.println("QuickSort + Random pivot: " + size + " elements" );

		measureSorter(size, sorter);
	}

	/**
	 * Measure the time for the QuickSort method that has the pivot point at the first element
	 * and has insertionsort at the last 20 element
	 * 
	 * @param size - the size of the vector
	 */
	public static void measureQuickSortInsertionMiddle(int size){
		QuickSortInsertionMiddle sorter = new QuickSortInsertionMiddle();
		System.out.println("QuickSort + Insertion + Middle pivot: " + size + " elements" );

		measureSorter(size, sorter);
	}

	/**
	 * Measure the time for the QuickSort method that has the pivot point at random elements
	 * and has insertionsort at the last 20 elements
	 * 
	 * @param size - the size of the vector
	 */
	public static void measureQuickSortInsertionRandom(int size){
		QuickSortInsertionRandom sorter = new QuickSortInsertionRandom();
		System.out.println("QuickSort + Insertion + Random pivot: " + size + " elements" );

		measureSorter(size, sorter);

	}

	/**
	 * Measures the time to sort the data using the sorter.
	 * Prints the results of the measurement to stdout.
	 */
	private static void measureTime(IntSorter sorter, Data data) {
		if (isBroken(sorter)) { // returns true if sorter doesn't pass tests
			System.out.println(sorter + " is broken");
			return;
		}
		int avarage = 0;
		final Stopwatch clock = new Stopwatch();
		final int reps = 100000;
		for (int k = 0; k < reps; k++) {

			clock.reset().start();
			{
				sorter.sort(data.get());
			}
			long time = (clock.stop().nanoseconds())/1000;

			if(k > 1000){
				avarage += time;
			}
		}
		System.out.println("| Avarage: " +(avarage/reps) + " �s |");
		
	}

	/**
	 * Private method that uses isBroken from SortTest so check is the current sorter is working
	 * 
	 * @param sorter
	 * @return
	 */
	private static boolean isBroken(IntSorter sorter){
		SortTest test = new SortTest();
		return test.isBroken(sorter);
	}
	
	/**
	 * A help method to avoid code duplication
	 * Send the wanted size for the data arrays and the current sorter
	 * 
	 * @param size
	 * @param sorter
	 */
	private static void measureSorter(int size, IntSorter sorter){
		//100 one's elements
		Data one = new Data(size, 1, Data.Order.RANDOM);

		//Random 100 elements
		Data rand = new Data(size, size,Data.Order.RANDOM);

		//100 elements ascending
		Data asc = new Data(size, size, Data.Order.ASCENDING);

		//100 elements descending
		Data des = new Data(size, size, Data.Order.DESCENDING);


		System.out.println("Many ones");
		measureTime(sorter, one);
		System.out.println();
		System.out.println("Random:");
		measureTime(sorter, rand);
		System.out.println();
		System.out.println("Ascending:");
		measureTime(sorter, asc);
		System.out.println();
		System.out.println("Descending:");
		measureTime(sorter, des);
		System.out.println("\n");
	}

}
